const state = { answers: [] };
const $ = (id) => document.getElementById(id);

function safeText(value) {
  return String(value ?? "");
}

function addOptions(select, values, label) {
  const unique = [...new Set(values.filter(Boolean))].sort((a, b) =>
    String(a).localeCompare(String(b), "ru", { numeric: true })
  );
  for (const value of unique) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = label ? label(value) : value;
    select.append(option);
  }
}

function makeCard(item) {
  const article = document.createElement("article");
  article.className = "card";

  const meta = document.createElement("p");
  meta.className = "meta";
  meta.textContent = `${item.grade} класс · ${item.subject}`;

  const title = document.createElement("h3");
  title.textContent = `${item.book} — ${item.task}`;

  const details = document.createElement("p");
  details.className = "meta";
  details.textContent = [item.author, item.edition].filter(Boolean).join(" · ") || "Автор и издание не указаны";

  const answerTitle = document.createElement("strong");
  answerTitle.textContent = "Ответ";
  const answer = document.createElement("div");
  answer.className = "answer";
  answer.textContent = item.answer || "Ответ ещё не добавлен.";

  article.append(meta, title, details, answerTitle, answer);

  if (item.solution) {
    const solution = document.createElement("details");
    solution.className = "solution";
    const summary = document.createElement("summary");
    summary.textContent = "Показать решение";
    const text = document.createElement("p");
    text.textContent = item.solution;
    solution.append(summary, text);
    article.append(solution);
  }

  if (item.source) {
    const source = document.createElement("p");
    source.className = "source";
    source.append("Источник: ");
    const link = document.createElement("a");
    link.href = item.source;
    link.textContent = "открыть";
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    source.append(link);
    article.append(source);
  }

  return article;
}

function render() {
  const query = $("search").value.trim().toLocaleLowerCase("ru");
  const grade = $("grade").value;
  const subject = $("subject").value;
  const book = $("book").value.trim().toLocaleLowerCase("ru");

  const filtered = state.answers.filter((item) => {
    const haystack = [item.book, item.author, item.task, item.answer, item.solution, item.subject]
      .map(safeText).join(" ").toLocaleLowerCase("ru");
    const bookText = [item.book, item.author, item.edition].map(safeText).join(" ").toLocaleLowerCase("ru");
    return (!query || haystack.includes(query))
      && (!grade || String(item.grade) === grade)
      && (!subject || item.subject === subject)
      && (!book || bookText.includes(book));
  });

  const results = $("results");
  results.replaceChildren(...filtered.map(makeCard));
  $("count").textContent = `Найдено: ${filtered.length}`;
  $("empty").hidden = filtered.length !== 0;
}

async function init() {
  try {
    const response = await fetch("data/answers.json");
    if (!response.ok) throw new Error("Не удалось загрузить базу");
    state.answers = await response.json();
    addOptions($("grade"), state.answers.map(x => String(x.grade)), v => `${v} класс`);
    addOptions($("subject"), state.answers.map(x => x.subject));
    render();
  } catch (error) {
    $("count").textContent = "Ошибка загрузки";
    $("empty").hidden = false;
    $("empty").textContent = "Не удалось загрузить data/answers.json. Откройте проект через GitHub Pages или локальный веб-сервер.";
  }
}

["search", "grade", "subject", "book"].forEach(id => $(id).addEventListener("input", render));
$("reset").addEventListener("click", () => {
  $("search").value = "";
  $("grade").value = "";
  $("subject").value = "";
  $("book").value = "";
  render();
});

init();
